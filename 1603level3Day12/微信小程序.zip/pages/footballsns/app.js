Page({
  data: {
    current: 0
  },
  onLoad: function () {
    // console.log('loaded.');
  },
  changeItem: function (e) {
    this.setData({
      current: e.detail.current
    })
  },
  switchSwiper: function (e) {
    this.setData({
      current: e.target.dataset.index
    })
  }
});
